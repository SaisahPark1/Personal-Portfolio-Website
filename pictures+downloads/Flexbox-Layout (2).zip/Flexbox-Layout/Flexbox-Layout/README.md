|display: flex| is used in many places throughout



|flex-direction| is used in the special card



|flex-wrap| is used in the article



|justify-content| is used in many places throughout



|align-items| is used in the hero section



|align-content| is used a few times throughout



|gap| is used a few times throughout



|order| is used in the hero section



|flex-grow| is used on call-to-action button and the footer



|flex-shrink| is used in a few places



|flex-basis| is used on the sidebar



|align-self| is used in the special card

